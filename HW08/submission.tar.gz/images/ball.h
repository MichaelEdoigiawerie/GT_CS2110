/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=10x10 ball ball.png 
 * Time-stamp: Tuesday 04/04/2023, 01:30:23
 * 
 * Image Information
 * -----------------
 * ball.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BALL_H
#define BALL_H

extern const unsigned short ball[100];
#define BALL_SIZE 200
#define BALL_LENGTH 100
#define BALL_WIDTH 10
#define BALL_HEIGHT 10

#endif

